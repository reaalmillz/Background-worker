# Discord Bot — Render Background Worker

A small Discord bot using `discord.js` v14, prepared to run continuously as a **Render Background Worker**.

## Included commands

- `/ping` — replies with the bot's WebSocket latency.
- `/invite` — shows the bot invite link.

## 1. Configure the Discord application

1. Open the [Discord Developer Portal](https://discord.com/developers/applications).
2. Select your application.
3. Open **Bot** and copy/reset the bot token. Keep it secret.
4. Make sure the bot is invited to your server using this link:

   https://discord.com/oauth2/authorize?client_id=1561021899314569399&permissions=125968&integration_type=0&scope=bot%20applications.commands

The application ID is already configured as `1561021899314569399`.

## 2. Upload this project to GitHub

Create a new repository, then upload all files in this folder. Do not upload your bot token or a real `.env` file.

## 3. Deploy on Render

1. Open [Render](https://render.com/) and sign in.
2. Choose **New +** → **Background Worker** (or deploy using the included `render.yaml`).
3. Connect the GitHub repository.
4. Use these settings if entering them manually:
   - **Runtime:** Node
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
5. Add environment variables:
   - `BOT_TOKEN` = your Discord bot token
   - `CLIENT_ID` = `1561021899314569399`
6. Create/deploy the worker and inspect its logs. You should see `Slash commands registered.` and `Logged in as ...`.

A Background Worker does not need an HTTP port or web server. Do not deploy it as a Web Service.

## 4. Test it

Once the worker is online, go to a server where the bot is installed and try `/ping` or `/invite`. Global slash commands may take a short time to appear.

## Local testing (optional)

Requires Node.js 20 or newer.

```bash
npm install
```

Create a `.env` file with `BOT_TOKEN` and `CLIENT_ID`. Node does not automatically load `.env` in every setup, so for simple local use either set environment variables in your terminal or install/use a dotenv loader. Do not commit `.env`.

## Troubleshooting

- **Missing BOT_TOKEN:** add the `BOT_TOKEN` environment variable in Render.
- **Invalid token / 401:** reset the token in Discord Developer Portal and update Render.
- **Slash commands don't appear:** confirm `CLIENT_ID` is the application ID, the bot is invited with `applications.commands` scope, and check Render logs.
- **Worker exits immediately:** check the first error in Render logs and verify the environment variables.
- **Permission errors:** review the bot's permissions in the Discord Developer Portal and the invite link.

Never share your bot token publicly. If it is exposed, reset it immediately in the Developer Portal.
