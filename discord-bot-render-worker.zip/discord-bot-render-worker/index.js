const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
} = require("discord.js");

const token = process.env.BOT_TOKEN;
const clientId = process.env.CLIENT_ID || "1561021899314569399";

if (!token) {
  console.error("Missing BOT_TOKEN environment variable.");
  process.exit(1);
}

const commands = [
  new SlashCommandBuilder()
    .setName("ping")
    .setDescription("Check whether the bot is online."),
  new SlashCommandBuilder()
    .setName("invite")
    .setDescription("Get the link to invite this bot to a server."),
].map((command) => command.toJSON());

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
});

client.once("ready", () => {
  console.log(`Logged in as ${client.user.tag}`);
  console.log("Discord bot is ready.");
});

client.on("interactionCreate", async (interaction) => {
  if (!interaction.isChatInputCommand()) return;

  try {
    if (interaction.commandName === "ping") {
      await interaction.reply(`Pong! 🏓 Latency: ${client.ws.ping} ms`);
    } else if (interaction.commandName === "invite") {
      const inviteUrl =
        "https://discord.com/oauth2/authorize?client_id=1561021899314569399&permissions=125968&integration_type=0&scope=bot%20applications.commands";
      await interaction.reply({
        content: `Invite me to your server: ${inviteUrl}`,
        ephemeral: true,
      });
    }
  } catch (error) {
    console.error("Failed to handle interaction:", error);
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction.reply({
        content: "Something went wrong while handling that command.",
        ephemeral: true,
      }).catch(() => {});
    }
  }
});

async function start() {
  // Register the slash commands globally. They can take a little while to appear.
  const rest = new REST({ version: "10" }).setToken(token);
  await rest.put(Routes.applicationCommands(clientId), { body: commands });
  console.log("Slash commands registered.");
  await client.login(token);
}

start().catch((error) => {
  console.error("Failed to start Discord bot:", error);
  process.exit(1);
});

process.on("unhandledRejection", (error) => {
  console.error("Unhandled promise rejection:", error);
});
